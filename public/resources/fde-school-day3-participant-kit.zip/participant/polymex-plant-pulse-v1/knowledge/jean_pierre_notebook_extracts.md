# Jean-Pierre's notebooks: extracts typed by the FDE team

*Four paper notebooks, 2009 to 2026, scanned with permission. Extracts relevant to sequencing, translated from French. Page references are to notebook and page.*

- **N1 p.12, March 2009.** Black to natural: dismount and clean the screw. 4 h. Saturday, morning shift only, with maintenance present. Never on a weekday: the line stays down too long and the week is lost.
- **N1 p.40, 2010.** Colored to natural: purge with natural, about 110 minutes. Colored to white: 90.
- **N2 p.7, 2014.** Glass-filled on M01, M02, M05 only (hardened screws installed 2013). Do not try on M04: the 2012 screw cost a month of output.
- **N2 p.31, 2015.** After glass, never white. Put a black or a color first.
- **N3 p.18, 2019.** PA6 on M03 and M06, dryer shared. Four hours between two PA6 starts. If not, the second line waits wet material and the batch is scrap.
- **N3 p.52, 2021.** Max three changeovers a shift. (In the margin, 2025, in Corinne's handwriting: "4 now".)
- **N4 p.3, 2024.** PP to PA6 or back: full purge, change the temperature profile, 2 h 30.
- **N4 p.22, 2025.** M04 at the weekend: see Marc.
