# Interview with Corinne, planner. Monday 4 May 2026, 8:10 to 8:55

*Notes taken by the FDE team, read back to Corinne and corrected by her. Translated from French.*

**Q. The ERP says sixty minutes for every changeover. Is that right?**
Corinne: No. Nobody here believes it. Natural to black is half an hour. Black to natural is a different story: you pull the screw and clean it. Four hours. Jean-Pierre had a rule for that, it is in his notebook. We only do it on Saturday morning, when maintenance is in.

**Q. What about glass-filled?**
Corinne: The glass grades wear the screws. Only M01, M02 and M05 have the hardened screws, everybody knows that. The ERP does not. And never white straight after glass: you get streaks for hours, the customer sends it back. Put something else in between.

**Q. And the polyamide?**
Corinne: PA6 has to be dried. The dryer is connected to M03 and M06 only. It is one dryer for both, and it needs four hours to prepare a batch. So I never start PA6 on both lines within four hours.

**Q. Is there a limit to how many changeovers a line can take?**
Corinne: Four a shift, maximum. After that the crew cannot keep up, they skip the checks and we get scrap. Jean-Pierre used to say three, but with the retail orders we cannot hold three anymore.

**Q. How do you sequence a day?**
Corinne: Light to dark when I can. Natural, white, colors, black. Then black runs into the weekend and we pull the screw on Saturday. When the retail orders come in small, everything breaks.

**Q. Who else knows all this?**
Corinne: Jean-Pierre. And Marc, for M04. That is it.
