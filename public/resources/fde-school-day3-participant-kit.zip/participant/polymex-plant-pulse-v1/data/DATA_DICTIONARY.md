# Data dictionary

## schedule_week19.csv
One row per order in Corinne's export of week 19 (Monday 4 May 06:00 to Monday 11 May 06:00), plant local time.
- `week`, `machine` (M01 to M07), `seq` (order of production on the line), `order_id`, `customer`
- `product_code`, `tonnes`
- `planned_changeover_start`: when the changeover into this order starts (empty for the first order of the week)
- `planned_start`, `planned_end`: the run of the order. The plan assumes every changeover takes 60 minutes and a run rate of 2.02 t/h (2.30 ideal × 0.88).

## products.csv
`product_code`, `family`, `description`, `color` (natural, white, blue, red, green, black).

## machines.csv
What the ERP says each machine can run. Check it against the knowledge files.

## changeover_matrix.csv
Minutes from one family to another, from Corinne's whiteboard, photographed on 30 April. Empty means no value was written. Same family: 25 minutes between two products, 0 for the same product; colored to another color: 60.

## erp_changeover_master.csv
The ERP's standard changeover time per product: 60 minutes for every product.

## Shifts
A 06:00 to 14:00, B 14:00 to 22:00, C 22:00 to 06:00. Shift C belongs to the day it starts.
