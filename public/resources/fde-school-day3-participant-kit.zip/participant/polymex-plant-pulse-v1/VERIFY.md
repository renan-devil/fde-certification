# Verification log (Verifier)

## Rules found independently in knowledge/

| Rule, in your words | Source (file, line) | In the rules file? | Same parameters? |
|---|---|---|---|
| | | | |

## Violations found by hand in week 19

| Machine | Order | Rule | Checker agrees? |
|---|---|---|---|
| | | | |

## Differences and how they were resolved
