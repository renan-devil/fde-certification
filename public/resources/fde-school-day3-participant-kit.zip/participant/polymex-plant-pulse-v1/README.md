# Polymex Plant Pulse v1: the schedule checker

FDE School, Day 3 afternoon lab. Build time 90 minutes, demo 3 minutes.

## The situation

It is Monday 4 May 2026. Corinne has exported next week's plan, week 19, from her workbook. The plan was built with the ERP's standard changeover of 60 minutes for every product. Corinne knows that is wrong, but the real rules live in her head and in Jean-Pierre's notebooks. Jean-Pierre retired in March.

Hervé wants to know before Friday whether week 19 will hold. Corinne wants a tool that checks a plan against her rules without her having to explain them every time.

## What to build

Add a "Schedule check" page to your Plant Pulse app:

1. **A rules file** (`rules/rules.yaml` or `.json`) that encodes every changeover and sequencing rule you can find in `knowledge/` and `data/changeover_matrix.csv`. One id per rule, a source for each (which document, which line), and `validated_by` left empty until Corinne (the trainer) validates it.
2. **A deterministic checker**, in code, that reads `data/schedule_week19.csv` and returns every violation with the rule id, the machine, the order and the time.
3. **A capacity check**: for each line, does the week still fit in 168 hours when real changeover times replace the ERP's 60 minutes?
4. **A grounded assistant**: a chat box where Hervé or Corinne asks questions in plain language. The model answers only through tools that call your rules file and your checker, cites rule ids and data rows, and says "not in the data" when it does not know.
5. **An eval harness**: `npm run eval` runs `evals/eval_set.jsonl` against the assistant and prints the pass rate. Add at least five questions of your own.

## How to work (teams of four)

- Builder: the checker and the assistant, with Claude Code.
- Verifier: reads the knowledge files without looking at the code and lists every rule independently; then compares with the rules file. Logs differences in `VERIFY.md`.
- Lead: owns the questions to Corinne. Each team may ask the trainer-as-Corinne three questions, in person.
- Storyteller: writes the one-paragraph answer to Hervé: does week 19 hold?

## Definition of done

- The checker finds every violation in week 19 and flags nothing that is allowed.
- The eval pass rate is printed, with the failures listed, and is at least 85% on the given set.
- No API key in the repository; the key lives in Vercel's environment variables.
- Deployed on Vercel, pushed to GitHub.

## Demo (three minutes)

1. The violations in week 19, live, with rule ids.
2. One question asked to the assistant that it correctly refuses.
3. Your eval pass rate, and the failure you have not fixed yet.
4. Your answer to Hervé in one sentence.
