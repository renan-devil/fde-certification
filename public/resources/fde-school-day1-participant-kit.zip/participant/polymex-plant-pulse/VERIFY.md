# Verification log (Pair B)

| Number | Our value | Pair A's value | Method (tool, formula, filters) | Match? |
|---|---|---|---|---|
| Plant extrusion OEE, Jan to Mar | | | | |
| M07 OEE | | | | |
| Changeovers, week of 23 to 29 March | | | | |

Anomalies we found in the data, and what we did about each:

-

What would make us trust these numbers more:

-
